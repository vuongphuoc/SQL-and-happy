export const basicTable = [
    { id: 1, name:'Joan Powell', position: 'Associate Developer', salary: 450870 },
    { id: 2, name:'Gavin Gibson', position: 'Account manager', salary: 230540 },
    { id: 3, name:'Julian Kerr', position: 'Senior Javascript Developer', salary: 55300 },
    { id: 4, name:'Cedric Kelly', position: 'Accountant', salary: 234100 },
    { id: 5, name:'Samantha May', position: 'Junior Technical Author', salary: 43198 },
]