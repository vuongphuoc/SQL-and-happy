import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-mail',
  templateUrl: './view-mail.component.html',
  styleUrls: ['./view-mail.component.scss']
})
export class ViewMailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
