import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-manager-list',
  templateUrl: './file-manager-list.component.html',
  styleUrls: ['./file-manager-list.component.scss']
})
export class FileManagerListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
