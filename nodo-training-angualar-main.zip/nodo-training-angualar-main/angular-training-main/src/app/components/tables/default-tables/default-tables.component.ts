import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-tables',
  templateUrl: './default-tables.component.html',
  styleUrls: ['./default-tables.component.scss']
})
export class DefaultTablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
