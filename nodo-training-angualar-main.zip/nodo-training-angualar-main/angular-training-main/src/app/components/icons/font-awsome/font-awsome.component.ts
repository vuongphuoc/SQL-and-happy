import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-font-awsome',
  templateUrl: './font-awsome.component.html',
  styleUrls: ['./font-awsome.component.scss']
})
export class FontAwsomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
