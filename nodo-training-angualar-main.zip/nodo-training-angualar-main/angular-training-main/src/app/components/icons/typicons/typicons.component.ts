import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-typicons',
  templateUrl: './typicons.component.html',
  styleUrls: ['./typicons.component.scss']
})
export class TypiconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
