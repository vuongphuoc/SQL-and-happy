import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-icons',
  templateUrl: './ionic-icons.component.html',
  styleUrls: ['./ionic-icons.component.scss']
})
export class IonicIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
