import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-height',
  templateUrl: './height.component.html',
  styleUrls: ['./height.component.scss']
})
export class HeightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
