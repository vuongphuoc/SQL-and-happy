import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-element-sizes',
  templateUrl: './form-element-sizes.component.html',
  styleUrls: ['./form-element-sizes.component.scss']
})
export class FormElementSizesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
