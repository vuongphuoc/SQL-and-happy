import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-mapping-list',
  templateUrl: './category-mapping-list.component.html',
  styleUrls: ['./category-mapping-list.component.scss']
})
export class CategoryMappingListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
