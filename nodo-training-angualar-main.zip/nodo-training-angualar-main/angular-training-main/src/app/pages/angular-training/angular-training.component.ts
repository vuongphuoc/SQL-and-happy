import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-training',
  templateUrl: './angular-training.component.html',
  styleUrls: ['./angular-training.component.scss']
})
export class AngularTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
